The c240891.c3d file contains over 100Mb of 3D data - 18,178 frames at 60Hz.  There is no analog data and only one identified trajectory.

It is only available as a zip download (under 1Mb in the ZIP file due to compression).