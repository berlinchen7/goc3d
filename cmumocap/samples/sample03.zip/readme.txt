Three sample c3d files generated on an Oxford Metrics Datastation.

gait-raw.c3d	normal adult gait trial. 
gait-pig.c3d	output from PluginGait containing gait events, 
		kinematics, and kinetics information.
gait-pig-nz.c3d data with events and a non-zero start time.