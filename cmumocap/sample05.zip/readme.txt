A single large c3d file generated using Oxford Metrics
Workstation software.

Stored in DEC-REAL format.
